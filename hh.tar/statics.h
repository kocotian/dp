static char pwdir[]			= "/usr/share/hmd";
static char pidpath[]		= "/tmp/hmd.pid";
static char notifycmd[]		= "notify-send";
