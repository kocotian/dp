/* pwdir - HMD & HMC chdirs here */
static char pwdir[]			= "/usr/share/hmd";
/* csvpath - path to file with modules */
static char csvpath[]		= "/usr/share/hmd/modules.csv";
/* pidpath - path to file where HMD' PID is stored */
static char pidpath[]		= "/tmp/hmd.pid";

#ifdef DP /* only for Don't Panic Daemon */
static char notifycmd[]		= "notify-send";
#endif

#ifdef DPM /* only for Don't Panic Manager */
#define COLOR_PRIMARY	TB_WHITE	/* Primary color (eg. borders) */
#define COLOR_ACCENT 	TB_YELLOW	/* Accent color (eg. modules list) */
#endif
