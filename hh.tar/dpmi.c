#define _XOPEN_SOURCE 700

/*
 * dpmi - don't panic module installer
 * tool for adding optional modules
 * for a don't panic daemon
 *
 * Copyright (c) 2020 by:
 * - Karolina Nocek
 * - Wojciech Tomasik
 * - Kacper Kocot
 *
 * For copying, redistribution, etc,
 * see LICENSE file.
 */

#include <sys/stat.h>
#include <sys/types.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "arg.h"
#include "http.h"
#include "util.c"

#define DPMI

typedef struct {
	int time;
	char *name;
} Module;

static void getmodule(char *argv[]);
static int parsecsv(char *csvpath);
static int savecsv(char *csvpath);

static Module *mods;
static volatile int modlen;
char *argv0;

#include "config.h"

static void
getmodule(char *argv[])
{
	char buf[BUFSIZ], *response, modpath[BUFSIZ];
	size_t responseSize;
	int iter = -1;
	FILE *modf;

	while (argv[++iter] != NULL) {
		printf("\033[1;34m:: \033[0mPobieram moduł \033[1m%s\033[0m...\n",
				argv[iter]);
		responseSize = httpGET("dp.kocotian.pl", 80, "/dl/", argv[iter], &response);
		if (getResponseStatus(response, responseSize) != 200) {
			udie("Wystąpił błąd \033[1m%d\033[0m",
					getResponseStatus(response, responseSize));
		}
		printf("\033[1;34m:: \033[0mOdebrano \033[1m%s\033[0m, zapisywanie...\n",
				argv[iter]);
		snprintf(modpath, BUFSIZ, "%s/modules/%s",
				pwdir, argv[iter]);
		if((modf = fopen(modpath, "w")) == NULL)
			udie("Nie udało się otworzyć pliku do zapisu:");
		fprintf(modf, "%s", truncateHeader(response));
		chmod(modpath, 0755);
		fclose(modf);
		mods = realloc(mods, sizeof(Module) * (++modlen + 1));
		mods[modlen - 1].time = 60;
		mods[modlen - 1].name = malloc(strlen(argv[iter]) + 1);
		strcpy(mods[modlen - 1].name, argv[iter]);
		strcat(mods[modlen - 1].name, "\n");
		free(response);
		savecsv(csvpath);
	}
}

static int
parsecsv(char *csvpath)
{
	FILE *csvf;
	int modlen = 0, iter = -1;
	char buf[256]; char *tok;
	free(mods);
	mods = malloc(sizeof(Module));
	if ((csvf = fopen(csvpath, "r")) == NULL) {
		perror(csvpath);
		exit(EXIT_FAILURE);
	}
	while (fgets(buf, 256, csvf) != NULL) {
		tok = strtok(buf, ",");
		mods[++iter].time = atoi(tok);
		tok = strtok(NULL, ",");
		mods[iter].name = malloc(strlen(tok));
		strncpy(mods[iter].name, tok, strlen(tok));
		mods = realloc(mods, sizeof(Module) * (++modlen + 1));
	}
	fclose(csvf);
	return modlen;
}

static int
savecsv(char *csvpath)
{
	FILE *csvf;
	int iter = -1;
	if ((csvf = fopen(csvpath, "w")) == NULL) {
		perror(csvpath);
		exit(EXIT_FAILURE);
	}
	while (++iter < modlen) {
		if (mods[iter].name != NULL)
			fprintf(csvf, "%d,%s",
					mods[iter].time, mods[iter].name);
	}
	fclose(csvf);
	return modlen;
}

static void
usage(void)
{
	die("użycie: %s [-g STR] [-r STR] [-i STR]\nwpisz \"man dpmi\" po więcej informacji",
			argv0);
}

int
main(int argc, char *argv[])
{
	struct stat dpstat;
	char flag = 0;
	FILE *dppidf;
	pid_t dppid;

	ARGBEGIN {
	case 'g': case 'r': case 'i': /* fallthrough */
		flag = ARGC();
		break;
	default:
		usage();
		break;
	} ARGEND;

/* 	if (stat(pidpath, &dpstat) < 0) */
/* 		dppid = -1; */
/* 	else { */
/* 		if ((dppidf = fopen(pidpath, "r")) == NULL) */
/* 			die("Błąd odczytu pliku zawierającego PID DP"); */
/* 		fscanf(dppidf, "%d", &dppid); */
/* 		fclose(dppidf); */
/* 	} */

	chdir(pwdir);
	modlen = parsecsv(csvpath);

	switch (flag) {
	case 'g':
		getmodule(argv);
		break;
	}
	return 0;
}
